#include <stdlib.h>
#include <stdio.h>

int main(int argc, char **argv){

  printf("Files in the directory are:\n");
  int pass = system("ls -la");

  if(pass == -1){ // Error check
    printf("Unsuccessful ls\n");
  }
}
