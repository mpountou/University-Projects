#include <stdio.h>
#include <unistd.h>


int main(int argc, char **argv){ 
 int some_value;

 printf("Forking process\n");
 fork();
 
 /* This part of the program is executed by two different proceses */
 printf("The process id is %d \n", getpid());
 
 some_value = getpid() + 10;
 printf("Some value is %d\n", some_value);
 
 execl("/bin/ls","/bin/ls","-l",NULL);

 /* This line is not executed because of th execl function */
 printf("This line is not printed\n");
}
