#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main(int argc, char **argv){
  
  int pid, status; 
  
  printf("Forking process\n");
  pid = fork();
  
  wait(&status);
  printf("The process id is %d \n", getpid());
  printf("value of pid is %d\n", pid);
  if (pid == 0){
    sleep(2);
    printf("I am the child, status is %d\n", status);
  } else {
    printf("I am the parent, status is %d\n", status);
  }

}
