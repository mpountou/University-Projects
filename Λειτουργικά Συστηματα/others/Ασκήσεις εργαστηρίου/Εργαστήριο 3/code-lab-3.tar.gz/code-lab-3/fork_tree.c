#include <stdio.h>   
#include <unistd.h>  
#include <stdlib.h>  
#include <errno.h>   
#include <sys/wait.h>

void createTree(int level)
{
  if(level > 0){

    int status;
    
    int left_child = fork();
    if(left_child != 0){
      
      int right_child = fork();
      if(right_child == 0){
	createTree(level - 1);
      }
      
    } else {
      createTree(level-1);
    }

    wait(&status);
    printf("Process Id: %d\n", getpid());
  }

  
}


int main(int argc, char **argv){

  int nlevels = atoi(argv[1]);
  
  createTree(nlevels);
}

