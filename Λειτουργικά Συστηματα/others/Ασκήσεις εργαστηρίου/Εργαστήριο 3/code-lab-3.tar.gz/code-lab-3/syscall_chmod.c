#include <unistd.h>
#include <sys/syscall.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv){

  int cmd = strtol(argv[2], NULL, 8); // Read a Hexadecimal number
  
  int rc = syscall(SYS_chmod, argv[1], cmd);

  if(rc == -1){
    fprintf(stderr, "chmod failed, errno: %d\n", errno);
  }

}
