#include <stdio.h>   
#include <unistd.h>  
#include <stdlib.h>  
#include <errno.h>   

int main(int argc, char *argv[])
{
  int i;
  printf("exec %s via fork",argv[1]);
  printf("with parameters:\n");
  for (i=1; i<argc; i++)
    {
      printf("argv[%d]=%s\n",i-1,argv[i]);
    }
  if (!fork())
    {
      execvp(argv[1],&argv[1]);
      /* The executable code of the process (child process)has just
       * been replaced by the executable file that has been
       * transferred into mother process as an origin of command shell
       * therefore the next commands will not be executed unless the
       * call of execv fails
       */
      perror("execvp");
      return;
    }
}
