#include <stdio.h>
int main(int argc, char **argv){
	char chin1;
	char chout1;
	chin1 = getchar();
	chout1 = chin1;
	printf( "%c\n", chout1 );
}
