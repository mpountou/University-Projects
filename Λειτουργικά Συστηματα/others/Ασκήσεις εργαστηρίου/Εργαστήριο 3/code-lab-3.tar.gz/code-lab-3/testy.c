#include <stdio.h>

int main(int argc, char **argv)
{

  char chin1;
  char chin2;
  char chout1;
  char chout2;

  chin1 = getchar();
  chin2 =getchar();
  chout1 = chin1;
  chout2 = chin2;
  printf( "%c, %c\n", chout1, chout2 );
}
