#include <stdio.h>
#include <unistd.h>

int main(int argc, char **argv){

  printf("Files in directory %s:\n", argv[1]);

  execl("/bin/ls", "/bin/ls", "-la", argv[1], NULL);
  
}
