#include <stdlib.h>
#include <stdio.h>

int main() {

  int *int_table;               /* Table of integers */
  int nelem;                    /* Number of elements */
  int i;
  
  printf("Enter number of elements:");
  scanf("%d", &nelem);
  int_table = (int *)malloc(nelem * sizeof(int));
  
  for (i = 0; i < nelem; i++) {
    printf("Element %d=", i);
    scanf("%d", &int_table[i]);
  }
  
}

