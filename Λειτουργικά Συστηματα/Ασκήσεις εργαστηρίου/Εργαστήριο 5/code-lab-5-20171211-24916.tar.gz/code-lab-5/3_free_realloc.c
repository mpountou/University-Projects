#include <stdlib.h>
#include <stdio.h>

int main() {

  int *iptr;
  
  iptr = (int *)malloc(10 * sizeof(int));
  /* iptr[0] to iptr[9] can now be used */

  iptr = (int *)realloc(iptr, 20 * sizeof(int));
  /* iptr[0] to iptr[9] retain old values
   * iptr[0] to iptr[19] can now be used */
  
  free(iptr);
  /* Do not access iptr[0] to iptr[19] from this point onwards */
  
}

