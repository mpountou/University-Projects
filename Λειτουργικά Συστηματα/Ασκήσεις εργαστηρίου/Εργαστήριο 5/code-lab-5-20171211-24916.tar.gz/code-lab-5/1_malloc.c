#include <stdlib.h>
#include <stdio.h>

int main() {

  char *c = (char *)malloc( 1000 * sizeof(char) );
  if (c == NULL) {
    printf("Out of memory!\n");
    return (1);
  }

}
